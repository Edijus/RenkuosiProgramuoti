from flask import Flask, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
import forms

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.sqlite?check_same_thread=False'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = '(/("ZOHDAJK)()kafau029)ÖÄ:ÄÖ:"OI§)"Z$()&"()!§(=")/$'

db = SQLAlchemy(app)


class MyTable(db.Model):
    __tablename__ = 'my_table'
    id = db.Column(db.Integer, primary_key=True)
    my_column = db.Column(db.String(100), nullable=False)


db.create_all()


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/add_form', methods=['GET', 'POST'])
def add_form():
    form = forms.AddForm()
    if form.validate_on_submit():
        my_table = MyTable(my_column=form.my_column.data)
        db.session.add(my_table)
        db.session.commit()
        return render_template('success.html')
    return render_template('add_form.html', form_in_html=form)


@app.route('/show')
def show():
    data = MyTable.query.all()
    return render_template('show.html', data_in_html=data)


if __name__ == '__main__':
    app.run(debug=True)
