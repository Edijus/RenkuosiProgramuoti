from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, PasswordField, validators
from wtforms.validators import DataRequired, EqualTo, ValidationError
import main


class AddForm(FlaskForm):
    my_column = StringField('My Column', [DataRequired()])
    submit = SubmitField('Submit')


class SignUpForm(FlaskForm):
    email_address = StringField('Email Address', validators=[DataRequired(), validators.Length(min=0, max=100)])
    first_name = StringField('First Name', validators=[DataRequired(), validators.Length(min=0, max=100)]])
    last_name = StringField('Last Name')
    password1 = PasswordField('Password', validators=[DataRequired(), validators.Length(min=0, max=100)])
    password2 = PasswordField('Password confirm', validators=[DataRequired(), EqualTo('password1', 'Passwords must match'), validators.Length(min=0, max=100)])
    submit = SubmitField('Sign Up')

    def validate_email_address(self, email_address):
        user = main.User.query.filter_by(email_address=self.email_address.data).first()
        if user:
            raise ValidationError('Email already exists. Sign in or use another email address.')


class SignInForm(FlaskForm):
    email_address = StringField('Email Address', validators=[DataRequired(), validators.Length(min=0, max=100)]])
    password = PasswordField('Password', validators=[DataRequired(), validators.Length(min=0, max=100)])
    submit = SubmitField('Sign In')
